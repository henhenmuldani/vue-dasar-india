<template>
  <div>
    <img alt="" class="d-block m-auto" src="../assets/loading.gif">
  </div>
</template>

<script>
export default {
  name: "Spinner"
};
</script>

<style scoped>

</style>