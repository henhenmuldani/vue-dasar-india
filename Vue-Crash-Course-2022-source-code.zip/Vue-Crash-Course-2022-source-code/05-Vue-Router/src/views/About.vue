<template>
  <div class="container mt-3">
    <div class="row">
      <div class="col">
        <p class="h3 fw-bold text-success">About Us</p>
        <p class="fst-italic">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias corporis exercitationem
          iusto
          maxime minima
          nisi officia officiis quaerat quos rem! Adipisci facere minus perferendis ratione reiciendis saepe sint
          suscipit temporibus.</p>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <ul class="list-group">
          <li class="list-group-item">
            App Name : <span class="fw-bold">Vue Router</span>
          </li>
          <li class="list-group-item">
            Author : <span class="fw-bold">NAVEEN SAGGAM</span>
          </li>
          <li class="list-group-item">
            App Version : <span class="fw-bold">1.0.1</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>

export default {
  components: {}
};
</script>