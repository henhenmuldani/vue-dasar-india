<template>
  <div class="container mt-5">
    <div class="row">
      <div class="col text-center">
        <img alt="Vue logo" src="../assets/logo.png" />
        <p class="h3 display-3 text-muted">Vue Router</p>
        <p class="fst-italic">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores aspernatur autem
          blanditiis consequuntur
          dolores, doloribus exercitationem, harum in ipsam iure mollitia saepe soluta tempora vel vero! Adipisci alias
          blanditiis doloremque eum exercitationem facilis inventore iure nam nihil pariatur quae, quia ratione
          reprehenderit totam ut, vero voluptatum. Consequuntur deleniti id quos?</p>
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: "Home",
  components: {}
};
</script>
